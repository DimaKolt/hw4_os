#include <unistd.h>

int main() {
    write(STDOUT_FILENO, "0", 1);
    sleep(1);
    return 0;
}
