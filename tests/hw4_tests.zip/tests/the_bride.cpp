#include <wait.h>
#include <unistd.h>
#include <cerrno>
#include <signal.h>
#include <vector>
#include <string>
#include <iostream>


enum Rc {
    BAD_ARGS        = -1,
    EXEC_NOT_FOUND  = -2,
    PIPE_ERROR      = -3
};

int char_to_signal(char c) {
    switch(c) {
        case 'K':
            return SIGKILL;
        case 'F':
            return SIGFPE;
        default:
            return SIGTERM;
    }
}

struct Child {
    std::string comm;
    pid_t       pid;
    int         signal;
    int         kill_error;
    int         retval;

    Child(const std::string& comm, char s) :
            comm(comm),
            signal(char_to_signal(s)),
            kill_error(0)
    {}
};

char dummy[64];

typedef std::vector<Child> Children;


void print_result(int retval, int kill_error) {
    std::cout << retval << ":" << kill_error << ";";
}

void print_result(const Child& child) {
    print_result(child.retval, child.kill_error);
}

void kill_no_one(int signal) {
    int err = 0;
    if (kill(34567, signal) < 0) {
        err = errno;
    }
    print_result(0, err);
}

int main(int argc, char* argv[]) {
    Children children;
    if (argc % 2 == 0) {
        return BAD_ARGS;
    }

    if (argc == 1) {
        kill_no_one(SIGTERM);
        kill_no_one(SIGKILL);
        kill_no_one(SIGPIPE);

        std::cout << std::endl;
        return 0;
    }

    for (int i = 2; i < argc; i += 2) {
        children.push_back(Child(argv[i-1], argv[i][0]));
    }

    int fd[2];
    if (pipe(fd) < 0) return PIPE_ERROR;

    for (Children::iterator child = children.begin(); child != children.end(); ++child) {
        child->pid = fork();
        if(child->pid == 0) {
            close(STDOUT_FILENO);
            dup(fd[1]);
            close(fd[0]);
            close(fd[1]);
	        execv(child->comm.c_str(), NULL);
            return EXEC_NOT_FOUND;
        }
    }

    close(fd[1]);
    {
        size_t left = children.size();
        while (left) {
            ssize_t got = read(fd[0], dummy, left);
            if (got < 0) {
                return PIPE_ERROR;
            }
            left -= got;
        }
    }

    for (Children::iterator child = children.begin(); child != children.end(); ++child) {
        if (kill(child->pid, child->signal) < 0) {
            child->kill_error = errno;
        }
    }

    for (Children::iterator child = children.begin(); child != children.end(); ++child) {
        int status;
        waitpid(child->pid, &status, 0);
        if (WIFEXITED(status)) {
            child->retval = WEXITSTATUS(status);
        } else if (WIFSIGNALED(status)) {
            child->retval = WTERMSIG(status);
        }

        print_result(*child);
    }

    std::cout << std::endl;
    
    return 0;
}
